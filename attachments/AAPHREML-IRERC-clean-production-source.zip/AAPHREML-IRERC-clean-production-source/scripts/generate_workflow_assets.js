/**
 * Generator script for AAPHREML-IRERC Workflow Manual (PDF) and Workflow Infographic Diagram (Image)
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const docsDir = path.resolve(rootDir, 'docs');
const tempDir = path.resolve(docsDir, 'workflow_temp_profile');

if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

// Convert logo to base64 for seamless embedding
let logoBase64 = '';
const logoPath = path.resolve(rootDir, 'logo.png');
if (fs.existsSync(logoPath)) {
  const logoBuf = fs.readFileSync(logoPath);
  logoBase64 = 'data:image/png;base64,' + logoBuf.toString('base64');
}

// ----------------------------------------------------------------------------
// 1. Build Comprehensive Workflow Manual HTML
// ----------------------------------------------------------------------------
const manualHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AAPHREML-IRERC Protocol Review & Governance Workflow Manual</title>
  <style>
    @page {
      size: A4;
      margin: 14mm 14mm 14mm 14mm;
      @bottom-right {
        content: counter(page);
      }
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, Helvetica, Arial, sans-serif;
      color: #1e293b;
      background: #ffffff;
      line-height: 1.55;
      font-size: 13.5px;
    }
    .page {
      padding: 10px 0;
      page-break-after: always;
    }
    .page:last-child {
      page-break-after: auto;
    }
    
    /* Header & Branding */
    .header-bar {
      border-bottom: 2px solid #0284c7;
      padding-bottom: 12px;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .inst-titles h1 {
      font-size: 19px;
      color: #0f172a;
      font-weight: 800;
      letter-spacing: -0.02em;
      text-transform: uppercase;
    }
    .inst-titles h2 {
      font-size: 14px;
      color: #0369a1;
      font-weight: 700;
      margin-top: 2px;
    }
    .inst-titles h3 {
      font-size: 12px;
      color: #64748b;
      font-weight: 500;
      margin-top: 1px;
    }
    .header-logo {
      height: 58px;
      max-width: 140px;
      object-fit: contain;
    }
    
    /* Cover / Hero */
    .hero-box {
      background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 60%, #0369a1 100%);
      color: #ffffff;
      border-radius: 12px;
      padding: 28px 24px;
      margin-bottom: 24px;
      box-shadow: 0 4px 14px rgba(15, 23, 42, 0.12);
    }
    .hero-badge {
      display: inline-block;
      background: rgba(255, 255, 255, 0.18);
      color: #38bdf8;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      padding: 4px 10px;
      border-radius: 20px;
      margin-bottom: 12px;
      border: 1px solid rgba(56, 189, 248, 0.3);
    }
    .hero-title {
      font-size: 24px;
      font-weight: 800;
      line-height: 1.25;
      margin-bottom: 10px;
      color: #ffffff;
    }
    .hero-subtitle {
      font-size: 13.5px;
      color: #cbd5e1;
      max-width: 90%;
      line-height: 1.5;
    }
    .meta-pills {
      display: flex;
      gap: 16px;
      margin-top: 16px;
      font-size: 11.5px;
      color: #94a3b8;
    }
    .meta-pills span strong {
      color: #f8fafc;
    }
    
    /* Section Headings */
    h2.section-heading {
      font-size: 16px;
      color: #0f172a;
      font-weight: 800;
      border-left: 4px solid #0284c7;
      padding-left: 10px;
      margin: 22px 0 14px 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    h3.sub-heading {
      font-size: 14px;
      color: #0369a1;
      font-weight: 700;
      margin: 14px 0 8px 0;
    }
    
    /* Flowchart & Steps */
    .flowchart-container {
      display: flex;
      flex-direction: column;
      gap: 10px;
      margin: 16px 0;
    }
    .flow-step {
      display: flex;
      align-items: stretch;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      overflow: hidden;
      page-break-inside: avoid;
    }
    .flow-num {
      width: 48px;
      background: #0284c7;
      color: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      font-weight: 800;
      flex-shrink: 0;
    }
    .flow-num.amber { background: #d97706; }
    .flow-num.emerald { background: #059669; }
    .flow-num.purple { background: #7c3aed; }
    .flow-num.indigo { background: #4f46e5; }
    .flow-num.rose { background: #e11d48; }
    .flow-num.slate { background: #475569; }
    
    .flow-body {
      padding: 10px 14px;
      flex: 1;
    }
    .flow-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 4px;
    }
    .flow-title {
      font-weight: 700;
      font-size: 13.5px;
      color: #0f172a;
    }
    .flow-role-tag {
      font-size: 10.5px;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 12px;
      background: #e0f2fe;
      color: #0369a1;
    }
    .flow-desc {
      font-size: 12px;
      color: #475569;
      line-height: 1.45;
    }
    .flow-outcomes {
      margin-top: 6px;
      font-size: 11px;
      background: #ffffff;
      padding: 6px 10px;
      border-radius: 5px;
      border: 1px dashed #cbd5e1;
      color: #334155;
    }
    
    /* Tables */
    table.data-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
      margin: 12px 0;
      page-break-inside: avoid;
    }
    table.data-table th {
      background: #f1f5f9;
      color: #0f172a;
      font-weight: 700;
      text-align: left;
      padding: 8px 10px;
      border: 1px solid #cbd5e1;
    }
    table.data-table td {
      padding: 7px 10px;
      border: 1px solid #e2e8f0;
      color: #334155;
      vertical-align: top;
    }
    table.data-table tr:nth-child(even) td {
      background: #f8fafc;
    }
    
    /* Badges */
    .badge {
      display: inline-block;
      font-size: 10px;
      font-weight: 700;
      padding: 2px 7px;
      border-radius: 4px;
      text-transform: uppercase;
    }
    .badge-blue { background: #e0f2fe; color: #0284c7; }
    .badge-green { background: #dcfce7; color: #15803d; }
    .badge-amber { background: #fef3c7; color: #b45309; }
    .badge-red { background: #fee2e2; color: #b91c1c; }
    .badge-purple { background: #f3e8ff; color: #7e22ce; }
    
    /* Callouts */
    .callout {
      background: #f0fdf4;
      border-left: 3px solid #16a34a;
      padding: 10px 14px;
      border-radius: 0 6px 6px 0;
      margin: 12px 0;
      font-size: 12px;
      color: #166534;
      page-break-inside: avoid;
    }
    .callout-warn {
      background: #fffbeb;
      border-left-color: #d97706;
      color: #92400e;
    }
    .callout-info {
      background: #f0f9ff;
      border-left-color: #0284c7;
      color: #075985;
    }
    
    /* Architecture Diagram Box */
    .arch-diagram {
      background: #0f172a;
      color: #f8fafc;
      border-radius: 8px;
      padding: 14px 16px;
      font-family: 'Consolas', 'Courier New', monospace;
      font-size: 11px;
      line-height: 1.4;
      margin: 12px 0;
      overflow-x: auto;
      page-break-inside: avoid;
    }
    
    .footer-note {
      margin-top: 18px;
      padding-top: 10px;
      border-top: 1px solid #e2e8f0;
      font-size: 10.5px;
      color: #94a3b8;
      display: flex;
      justify-content: space-between;
    }
  </style>
</head>
<body>

  <!-- PAGE 1: TITLE & EXECUTIVE WORKFLOW OVERVIEW -->
  <div class="page">
    <div class="header-bar">
      <div class="inst-titles">
        <h1>Addis Ababa City Administration Health Bureau</h1>
        <h2>AAPHREML Institutional Research Ethics Review Committee (IRERC)</h2>
        <h3>Protocol Management, Scientific & Ethics Review SOP Workflow Manual</h3>
      </div>
      ${logoBase64 ? `<img src="${logoBase64}" class="header-logo" alt="AACAHB Logo">` : ''}
    </div>

    <div class="hero-box">
      <div class="hero-badge">Standard Operating Procedure & Lifecycle Architecture</div>
      <div class="hero-title">Comprehensive Ethics Review & Protocol Governance Workflow</div>
      <div class="hero-subtitle">
        An end-to-end procedural guide detailing investigator protocol submission, administrative intake, multidisciplinary review assignments, ethics deliberation, formal clearance certificate issuance, and post-clearance oversight.
      </div>
      <div class="meta-pills">
        <span><strong>Protocol Code:</strong> AAPHREML-IRERC-YYYY-XXXX</span>
        <span><strong>Review Window:</strong> 7 Working Days</span>
        <span><strong>Quorum Rule:</strong> Minimum 2 Members</span>
        <span><strong>Clearance Validity:</strong> 1 Calendar Year</span>
      </div>
    </div>

    <h2 class="section-heading">1. High-Level Protocol Review Lifecycle</h2>
    
    <div class="flowchart-container">
      <div class="flow-step">
        <div class="flow-num">1</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Protocol Submission & Investigator Intake</span>
            <span class="flow-role-tag">Principal Investigator</span>
          </div>
          <div class="flow-desc">PI completes online application with study metadata, health focus area, study sites, and uploads mandatory dossiers (Protocol, ICF, PIS, Data Tools, CVs, Budget, Ethics Training Certificates).</div>
          <div class="flow-outcomes"><strong>Initial Status:</strong> <code>Submitted</code> | Stored in secure cloud folder <code>AAPHREML-IRERC_Documents/&lt;protocol_id&gt;/</code></div>
        </div>
      </div>

      <div class="flow-step">
        <div class="flow-num amber">2</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Administrative Screening & Completeness Verification</span>
            <span class="flow-role-tag">IRERC Secretariat</span>
          </div>
          <div class="flow-desc">Secretariat verifies submitted documentation for regulatory compliance, completeness, and eligibility. Document slots are itemized and verified.</div>
          <div class="flow-outcomes"><strong>Branching Outcomes:</strong> <code>Incomplete / Correction Required</code> (Deficiency dispatch to PI) OR <code>Submission Complete</code> (Advanced to Chair)</div>
        </div>
      </div>

      <div class="flow-step">
        <div class="flow-num purple">3</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Review Type Classification</span>
            <span class="flow-role-tag">Chairperson / Secretariat</span>
          </div>
          <div class="flow-desc">Risk assessment categorizes study into appropriate ethical review pathway according to Ethiopian national guidelines and Helsinki declarations.</div>
          <div class="flow-outcomes"><strong>Pathways:</strong> <span class="badge badge-purple">Full Board Review</span> (Greater than minimal risk / Clinical) | <span class="badge badge-blue">Expedited Review</span> (Minimal risk) | <span class="badge badge-green">Exemption Review</span> (De-identified / Negligible risk)</div>
        </div>
      </div>

      <div class="flow-step">
        <div class="flow-num indigo">4</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Multidisciplinary Reviewer Assignment & COI Clearance</span>
            <span class="flow-role-tag">Secretariat & Reviewers</span>
          </div>
          <div class="flow-desc">System maps study category to committee professional expertise. Reviewers must declare absence of Conflict of Interest (COI) before accessing unredacted protocol records.</div>
          <div class="flow-outcomes"><strong>Status:</strong> <code>Reviewer Assigned</code> &rarr; <code>Under Review</code> | Review turnaround deadline set (7 working days).</div>
        </div>
      </div>
    </div>

    <div class="footer-note">
      <span>AAPHREML-IRERC SOP Workflow Manual &bull; Confidential &bull; Addis Ababa Health Bureau</span>
      <span>Page 1 of 4</span>
    </div>
  </div>

  <!-- PAGE 2: STAGES 5 TO 8 & DECISION PATHWAYS -->
  <div class="page">
    <div class="header-bar">
      <div class="inst-titles">
        <h1>Addis Ababa City Administration Health Bureau</h1>
        <h2>AAPHREML Institutional Research Ethics Review Committee (IRERC)</h2>
        <h3>Protocol Review & Decision Governance (Continued)</h3>
      </div>
      ${logoBase64 ? `<img src="${logoBase64}" class="header-logo" alt="AACAHB Logo">` : ''}
    </div>

    <div class="flowchart-container">
      <div class="flow-step">
        <div class="flow-num emerald">5</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Standardized 20-Point Ethics Assessment</span>
            <span class="flow-role-tag">Assigned Reviewers</span>
          </div>
          <div class="flow-desc">Reviewers evaluate protocols against 20 standardized dimensions: Scientific Validity, Sample Size, Informed Consent, Local Language Translations (Amharic), Risk/Benefit Ratio, Vulnerable Populations, and Data Security.</div>
          <div class="flow-outcomes"><strong>Outputs:</strong> Individual item scores, textual critique, recommended outcome, and formal assessment form sign-off.</div>
        </div>
      </div>

      <div class="flow-step">
        <div class="flow-num rose">6</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Committee Deliberation & Formal IRERC Decision</span>
            <span class="flow-role-tag">Full IRERC Board / Chairperson</span>
          </div>
          <div class="flow-desc">Convened meeting with verified Ethics Quorum (&ge; 2 members). Reviewer assessments synthesized and committee votes on formal decision record.</div>
          <div class="flow-outcomes"><strong>Formal Outcomes:</strong> <code>Approved</code> | <code>Approved with Conditions</code> | <code>Modifications Required</code> | <code>Deferred</code> | <code>Not Approved</code></div>
        </div>
      </div>

      <div class="flow-step">
        <div class="flow-num slate">7</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Decision Communication & Certificate Issuance</span>
            <span class="flow-role-tag">Secretariat & Chairperson</span>
          </div>
          <div class="flow-desc">Formal Ethics Clearance Letter generated with unique Decision ID, valid from/until dates (1-year standard validity), signed by Chairperson, and dispatched to PI.</div>
          <div class="flow-outcomes"><strong>Status:</strong> <code>Decision Communicated</code> &rarr; <code>Data Collection Active</code> (Post-clearance monitoring enabled)</div>
        </div>
      </div>

      <div class="flow-step">
        <div class="flow-num indigo">8</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Post-Approval Monitoring, Amendments & Study Closeout</span>
            <span class="flow-role-tag">PI, Secretariat & Committee</span>
          </div>
          <div class="flow-desc">Full study lifecycle oversight: Annual Continuing Review (60/30-day alerts), Protocol Amendments (AMD-01...), Progress Reports, Adverse Event Reports, and Final Closeout Report.</div>
          <div class="flow-outcomes"><strong>Final Status:</strong> <code>Closeout Complete</code> &rarr; <code>Study Archived</code> (Permanent institutional archive)</div>
        </div>
      </div>
    </div>

    <h2 class="section-heading">2. Formal IRERC Committee Decision Matrix</h2>
    <table class="data-table">
      <thead>
        <tr>
          <th style="width: 22%;">Decision Outcome</th>
          <th style="width: 32%;">Criteria & Ethical Threshold</th>
          <th style="width: 26%;">Protocol Next Action</th>
          <th style="width: 20%;">Validity Period</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><span class="badge badge-green">Approved</span></td>
          <td>Fully satisfies all 20 scientific and ethical criteria. Acceptable risk-benefit balance, complete protections.</td>
          <td>Generates Official Approval Certificate; PI authorized to commence field data collection.</td>
          <td><strong>1 Year</strong> from decision date</td>
        </tr>
        <tr>
          <td><span class="badge badge-amber">Approved with Conditions</span></td>
          <td>Substantively ethical; requires minor administrative clarifications, document adjustments, or site permits.</td>
          <td>Conditional approval issued; conditions tracked until verified by Secretariat.</td>
          <td><strong>1 Year</strong> upon condition clearance</td>
        </tr>
        <tr>
          <td><span class="badge badge-blue">Modifications Required</span></td>
          <td>Significant methodological or ethical deficiencies requiring substantive revision and re-evaluation.</td>
          <td>Protocol returned to PI with itemized feedback; must submit revised version.</td>
          <td>N/A (Pending re-review)</td>
        </tr>
        <tr>
          <td><span class="badge badge-purple">Deferred</span></td>
          <td>Missing critical external input, pending institutional clearance, or independent ad-hoc expert consultation needed.</td>
          <td>Placed on next committee meeting agenda after clarifications received.</td>
          <td>N/A (Hold status)</td>
        </tr>
        <tr>
          <td><span class="badge badge-red">Not Approved</span></td>
          <td>Unjustified physical/social risks, scientific invalidity, or non-compliance with Declaration of Helsinki.</td>
          <td>Formal rejection notice issued with detailed justification. Study terminated.</td>
          <td>Permanent Rejection</td>
        </tr>
      </tbody>
    </table>

    <div class="callout callout-info">
      <strong>Multidisciplinary Reviewer Quorum Rule:</strong> IRERC decisions require verification of ethical quorum (&ge; 2 members across diverse professional categories). Voting results, dissent, and conflict-of-interest recusals are recorded in immutable audit logs.
    </div>

    <div class="footer-note">
      <span>AAPHREML-IRERC SOP Workflow Manual &bull; Confidential &bull; Addis Ababa Health Bureau</span>
      <span>Page 2 of 4</span>
    </div>
  </div>

  <!-- PAGE 3: 20-POINT ASSESSMENT CRITERIA & REVIEWER MATCHING -->
  <div class="page">
    <div class="header-bar">
      <div class="inst-titles">
        <h1>Addis Ababa City Administration Health Bureau</h1>
        <h2>AAPHREML Institutional Research Ethics Review Committee (IRERC)</h2>
        <h3>20-Point Assessment Standard & Professional Categorization</h3>
      </div>
      ${logoBase64 ? `<img src="${logoBase64}" class="header-logo" alt="AACAHB Logo">` : ''}
    </div>

    <h2 class="section-heading">3. Multidisciplinary Category & Expert Matching Matrix</h2>
    <table class="data-table">
      <thead>
        <tr>
          <th>Submission Health Focus Area</th>
          <th>Standardized Study Category</th>
          <th>Target Committee Professional Expertise</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>Communicable diseases / NTDs / Biomedical</td>
          <td>Biomedical & Laboratory</td>
          <td><strong>Laboratory Scientist</strong></td>
        </tr>
        <tr>
          <td>Non-communicable diseases / Interventions</td>
          <td>Clinical Trial / Interventional</td>
          <td><strong>Clinical Expert</strong></td>
        </tr>
        <tr>
          <td>RMNCH (Reproductive, Maternal, Child Health)</td>
          <td>Observational / Epidemiological</td>
          <td><strong>Public Health Expert</strong></td>
        </tr>
        <tr>
          <td>Food & Nutrition / Health systems & services</td>
          <td>Public Health & Health Systems</td>
          <td><strong>Public Health Expert</strong></td>
        </tr>
        <tr>
          <td>WASH / Environmental & workplace health</td>
          <td>Environmental & Occupational Health</td>
          <td><strong>Environmental Health Professional</strong></td>
        </tr>
        <tr>
          <td>Mental health / Socio-behavioral studies</td>
          <td>Socio-behavioral & Qualitative</td>
          <td><strong>Ethics / Legal Expert</strong></td>
        </tr>
      </tbody>
    </table>

    <h2 class="section-heading">4. Standard 20-Point Ethics Assessment Framework</h2>
    <table class="data-table">
      <thead>
        <tr>
          <th style="width: 10%;">Code</th>
          <th style="width: 28%;">Assessment Domain</th>
          <th style="width: 62%;">Specific Reviewer Evaluation Criteria</th>
        </tr>
      </thead>
      <tbody>
        <tr><td>CRIT_01</td><td>Scientific Justification</td><td>Is research rationale clearly justified, novel, and scientifically sound?</td></tr>
        <tr><td>CRIT_02</td><td>Study Design</td><td>Is design (RCT, cross-sectional, qualitative) appropriate for stated aims?</td></tr>
        <tr><td>CRIT_03</td><td>Sample Size</td><td>Is sample size statistically powered or qualitatively saturated?</td></tr>
        <tr><td>CRIT_04</td><td>Inclusion/Exclusion</td><td>Are eligibility criteria clearly defined, equitable, and non-discriminatory?</td></tr>
        <tr><td>CRIT_05</td><td>Data Collection</td><td>Are questionnaires, laboratory SOPs, and instruments validated?</td></tr>
        <tr><td>CRIT_06</td><td>Quality Assurance</td><td>Are data verification, supervisor audits, and calibration protocols adequate?</td></tr>
        <tr><td>CRIT_07</td><td>Informed Consent</td><td>Is informed consent voluntary, comprehensible, and free of undue influence?</td></tr>
        <tr><td>CRIT_08</td><td>Local Language</td><td>Are information sheets and consent translated accurately to local languages (Amharic)?</td></tr>
        <tr><td>CRIT_09</td><td>Risk Minimization</td><td>Are physical, psychological, social, and legal risks identified and minimized?</td></tr>
        <tr><td>CRIT_10</td><td>Direct Benefits</td><td>Are expected benefits to participants/community reasonable relative to risks?</td></tr>
        <tr><td>CRIT_11</td><td>Vulnerable Groups</td><td>Are children, pregnant women, prisoners, or marginalized groups safeguarded?</td></tr>
        <tr><td>CRIT_12</td><td>Confidentiality</td><td>Are de-identification, encryption, password protection, and access controls robust?</td></tr>
        <tr><td>CRIT_13</td><td>Compensation</td><td>Is compensation for time/transport reasonable and non-coercive?</td></tr>
        <tr><td>CRIT_14</td><td>Investigator Competence</td><td>Do investigators possess verified CVs and valid ethics training certificates?</td></tr>
        <tr><td>CRIT_15</td><td>Site Suitability</td><td>Are facilities, clinics, or laboratories equipped to handle study protocols?</td></tr>
        <tr><td>CRIT_16</td><td>Community Impact</td><td>Are community engagement and findings dissemination planned for local stakeholders?</td></tr>
        <tr><td>CRIT_17</td><td>Conflict of Interest</td><td>Are all potential financial, academic, and institutional conflicts declared?</td></tr>
        <tr><td>CRIT_18</td><td>Study Timeline</td><td>Is workplan realistic with sufficient recruitment and follow-up buffers?</td></tr>
        <tr><td>CRIT_19</td><td>Budget Transparency</td><td>Is budget itemized, realistic, and free of inappropriate financial inducements?</td></tr>
        <tr><td>CRIT_20</td><td>Regulatory Adherence</td><td>Does study strictly comply with Ethiopian National Guidelines & Helsinki Accord?</td></tr>
      </tbody>
    </table>

    <div class="footer-note">
      <span>AAPHREML-IRERC SOP Workflow Manual &bull; Confidential &bull; Addis Ababa Health Bureau</span>
      <span>Page 3 of 4</span>
    </div>
  </div>

  <!-- PAGE 4: TECHNICAL ARCHITECTURE, CI/CD & LIFECYCLE BRANCHES -->
  <div class="page">
    <div class="header-bar">
      <div class="inst-titles">
        <h1>Addis Ababa City Administration Health Bureau</h1>
        <h2>AAPHREML Institutional Research Ethics Review Committee (IRERC)</h2>
        <h3>Technical Architecture, Security & Post-Approval Lifecycle</h3>
      </div>
      ${logoBase64 ? `<img src="${logoBase64}" class="header-logo" alt="AACAHB Logo">` : ''}
    </div>

    <h2 class="section-heading">5. Technical Architecture & Communication Workflow</h2>
    <div class="arch-diagram">
+-----------------------------------------------------------------------------------+
|                           CLIENT TIER (Public Access)                             |
|  GitHub Pages (https://aardmc.github.io/AAPHREML-IRERC/)                          |
|  - Vanilla HTML5 / Modern CSS / Reactive JavaScript (No external framework bloat) |
|  - Communicates via origin-checked window.postMessage() RPC Channel               |
+-----------------------------------------------------------------------------------+
                                        | (origin-checked iframe bridge)
                                        v
+-----------------------------------------------------------------------------------+
|                        APPLICATION SERVER (Google Apps Script)                    |
|  Apps Script Web App Backend (Executes as Institutional Service Account)           |
|  - Bridge.html: Validates parent origin (aardmc.github.io) & enforces API allowlist|
|  - Auth.gs: Salted SHA-256 password hashing & expiring server session tokens      |
|  - API Dispatcher: Protocol submission, Screening, Reviews, Decisions, Lifecycle |
|  - LockService: Transaction locks prevent race conditions on concurrent writes     |
+-----------------------------------------------------------------------------------+
                  |                                                 |
                  v                                                 v
+------------------------------------+            +---------------------------------+
|      DATABASE STORAGE TIER         |            |      DOCUMENT REPOSITORY        |
|  Google Sheets Relational Database |            |  Google Drive Dedicated Folder  |
|  - Tabular Schemas (Protocols,     |            |  - AAPHREML-IRERC_Documents/    |
|    Users, Reviews, Decisions)      |            |    &lt;protocol_id&gt;/ (Locked PDFs) |
|  - Scanner Integration Sheet       |            |  - Staged Proposal Scans/       |
|  - Immutable Audit Log Table       |            |  - Restricted Signature Assets  |
+------------------------------------+            +---------------------------------+
    </div>

    <h2 class="section-heading">6. Post-Approval Protocol Lifecycle Management</h2>
    <div class="flowchart-container">
      <div class="flow-step">
        <div class="flow-num purple">A</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Protocol Amendment Subsystem (AMD-01, AMD-02...)</span>
            <span class="flow-role-tag">Investigator &rarr; Chairperson</span>
          </div>
          <div class="flow-desc">Guarantees approved baseline protocol is NEVER overwritten. Amendments are registered with separate sequential identifiers, rationale, and diffs. Chair classifies amendment as Expedited (minor changes) or Full Board (major changes).</div>
        </div>
      </div>

      <div class="flow-step">
        <div class="flow-num amber">B</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Annual Continuing Review & Clearance Renewal</span>
            <span class="flow-role-tag">Secretariat Automated Oversight</span>
          </div>
          <div class="flow-desc">Ethical clearance expires after 12 months. Automated system warnings fire at 60 and 30 days prior to expiry. PI must submit progress metrics, enrolled participant counts, and safety updates to renew clearance.</div>
        </div>
      </div>

      <div class="flow-step">
        <div class="flow-num emerald">C</div>
        <div class="flow-body">
          <div class="flow-head">
            <span class="flow-title">Study Closeout, Final Reporting & Permanent Archival</span>
            <span class="flow-role-tag">Investigator & Committee</span>
          </div>
          <div class="flow-desc">Upon study conclusion, PI submits Final Closeout Report summarizing outcomes, sample retention/destruction, and dissemination plans. Committee issues formal Closeout Acknowledgment and archives protocol.</div>
        </div>
      </div>
    </div>

    <div class="callout">
      <strong>Regulatory Compliance & Data Integrity:</strong> All protocol lifecycle actions—from initial intake to final archiving—are immutably logged in the system audit trail with user identity, timestamp (Africa/Addis_Ababa), old status, new status, and full narrative justification.
    </div>

    <div class="footer-note">
      <span>AAPHREML-IRERC SOP Workflow Manual &bull; Confidential &bull; Addis Ababa Health Bureau</span>
      <span>Page 4 of 4</span>
    </div>
  </div>

</body>
</html>
`;

// ----------------------------------------------------------------------------
// 2. Build High-Resolution Infographic Diagram HTML (Image Source)
// ----------------------------------------------------------------------------
const diagramHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AAPHREML-IRERC Ethics Review Workflow Infographic</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      width: 1200px;
      padding: 32px;
      font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
      background: #f8fafc;
      color: #0f172a;
    }
    .diagram-card {
      background: #ffffff;
      border-radius: 16px;
      padding: 32px;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.08), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
      border: 1px solid #e2e8f0;
    }
    .infographic-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 3px solid #0284c7;
      padding-bottom: 20px;
      margin-bottom: 28px;
    }
    .header-text h1 {
      font-size: 26px;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: -0.02em;
    }
    .header-text h2 {
      font-size: 16px;
      font-weight: 700;
      color: #0284c7;
      margin-top: 4px;
    }
    .header-text p {
      font-size: 13px;
      color: #64748b;
      margin-top: 4px;
    }
    .infographic-logo {
      height: 70px;
      max-width: 180px;
      object-fit: contain;
    }
    
    /* Pipeline Grid */
    .pipeline-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      margin-bottom: 28px;
      position: relative;
    }
    .pipe-col {
      background: #f1f5f9;
      border-radius: 12px;
      padding: 16px;
      border: 1px solid #cbd5e1;
      display: flex;
      flex-direction: column;
      position: relative;
    }
    .pipe-step-num {
      position: absolute;
      top: -12px;
      left: 16px;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: #0284c7;
      color: #ffffff;
      font-weight: 800;
      font-size: 13px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 4px rgba(2, 132, 199, 0.3);
    }
    .pipe-col.amber .pipe-step-num { background: #d97706; }
    .pipe-col.purple .pipe-step-num { background: #7c3aed; }
    .pipe-col.emerald .pipe-step-num { background: #059669; }
    
    .pipe-title {
      font-weight: 800;
      font-size: 14.5px;
      color: #0f172a;
      margin-top: 8px;
      margin-bottom: 4px;
    }
    .pipe-actor {
      font-size: 11px;
      font-weight: 700;
      color: #0369a1;
      text-transform: uppercase;
      margin-bottom: 10px;
    }
    .pipe-details {
      font-size: 12px;
      color: #334155;
      line-height: 1.45;
      flex: 1;
    }
    .pipe-badge {
      margin-top: 10px;
      background: #ffffff;
      padding: 6px 8px;
      border-radius: 6px;
      font-size: 11px;
      font-weight: 600;
      border: 1px dashed #cbd5e1;
      color: #1e293b;
    }

    /* Decision Split Box */
    .decision-section {
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      color: #ffffff;
      border-radius: 12px;
      padding: 24px;
      margin-bottom: 28px;
    }
    .sec-title {
      font-size: 18px;
      font-weight: 800;
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .decision-cards {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
    }
    .d-card {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 8px;
      padding: 14px;
    }
    .d-badge {
      display: inline-block;
      padding: 3px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 800;
      text-transform: uppercase;
      margin-bottom: 6px;
    }
    .d-badge.green { background: #16a34a; color: #ffffff; }
    .d-badge.amber { background: #d97706; color: #ffffff; }
    .d-badge.red { background: #dc2626; color: #ffffff; }
    .d-desc {
      font-size: 12px;
      color: #cbd5e1;
      line-height: 1.4;
    }

    /* Bottom Lifecycle Row */
    .lifecycle-row {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 16px;
    }
    .life-card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-left: 4px solid #0284c7;
      border-radius: 0 8px 8px 0;
      padding: 14px;
    }
    .life-card.amber { border-left-color: #d97706; }
    .life-card.green { border-left-color: #10b981; }
    .life-card h4 {
      font-size: 13px;
      font-weight: 700;
      color: #0f172a;
      margin-bottom: 4px;
    }
    .life-card p {
      font-size: 11.5px;
      color: #475569;
      line-height: 1.4;
    }

    .infographic-footer {
      margin-top: 24px;
      padding-top: 14px;
      border-top: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      font-size: 11px;
      color: #64748b;
    }
  </style>
</head>
<body>
  <div class="diagram-card">
    <div class="infographic-header">
      <div class="header-text">
        <h1>AAPHREML-IRERC Research Ethics Review Workflow</h1>
        <h2>Addis Ababa City Administration Health Bureau (AACAHB)</h2>
        <p>Operational Architecture &bull; Protocol Intake to Ethical Clearance & Post-Approval Oversight</p>
      </div>
      ${logoBase64 ? `<img src="${logoBase64}" class="infographic-logo" alt="Logo">` : ''}
    </div>

    <!-- PIPELINE STAGES 1-4 -->
    <div class="pipeline-grid">
      <div class="pipe-col">
        <div class="pipe-step-num">1</div>
        <div class="pipe-title">Intake & Submission</div>
        <div class="pipe-actor">Principal Investigator</div>
        <div class="pipe-details">
          PI submits online protocol application, research proposal, consent forms, data collection tools, CVs, budget, and training certificates.
        </div>
        <div class="pipe-badge">Status: <code>Submitted</code></div>
      </div>

      <div class="pipe-col amber">
        <div class="pipe-step-num">2</div>
        <div class="pipe-title">Administrative Check</div>
        <div class="pipe-actor">IRERC Secretariat</div>
        <div class="pipe-details">
          Secretariat checks document completeness and eligibility. If incomplete, issues deficiency notice; if complete, logs to audit trail.
        </div>
        <div class="pipe-badge">Status: <code>Submission Complete</code></div>
      </div>

      <div class="pipe-col purple">
        <div class="pipe-step-num">3</div>
        <div class="pipe-title">Classification</div>
        <div class="pipe-actor">Chairperson / Secretariat</div>
        <div class="pipe-details">
          Classifies protocol risk level into: Full Board Review (&gt; minimal risk), Expedited Review (minimal risk), or Exemption (negligible).
        </div>
        <div class="pipe-badge">Pathway: Expedited vs Full Board</div>
      </div>

      <div class="pipe-col emerald">
        <div class="pipe-step-num">4</div>
        <div class="pipe-title">Reviewer Matching</div>
        <div class="pipe-actor">Secretariat & Reviewers</div>
        <div class="pipe-details">
          Matches study category to committee expertise (Clinical, Lab, Public Health, Environmental, Ethics). COI declaration mandatory.
        </div>
        <div class="pipe-badge">Turnaround: 7 Working Days</div>
      </div>
    </div>

    <!-- PIPELINE STAGES 5-8 -->
    <div class="pipeline-grid">
      <div class="pipe-col">
        <div class="pipe-step-num">5</div>
        <div class="pipe-title">20-Point Assessment</div>
        <div class="pipe-actor">Assigned Reviewers</div>
        <div class="pipe-details">
          In-depth scoring across 20 points: Scientific Rigor, Sample Size, Informed Consent, Local Languages (Amharic), Risk vs Benefit, and Data Privacy.
        </div>
        <div class="pipe-badge">Status: <code>Under Assessment</code></div>
      </div>

      <div class="pipe-col amber">
        <div class="pipe-step-num">6</div>
        <div class="pipe-title">Quorum Deliberation</div>
        <div class="pipe-actor">Full IRERC Board</div>
        <div class="pipe-details">
          Formal committee meeting convened with verified Quorum (&ge; 2 members). Reviewers deliberate and vote on formal committee decision.
        </div>
        <div class="pipe-badge">Status: <code>IRERC Decision</code></div>
      </div>

      <div class="pipe-col purple">
        <div class="pipe-step-num">7</div>
        <div class="pipe-title">Certificate Issuance</div>
        <div class="pipe-actor">Chairperson & Secretariat</div>
        <div class="pipe-details">
          Official Ethics Clearance Certificate generated with unique Decision ID, valid from/until dates, and conditions. Sent to PI.
        </div>
        <div class="pipe-badge">Validity: 1 Calendar Year</div>
      </div>

      <div class="pipe-col emerald">
        <div class="pipe-step-num">8</div>
        <div class="pipe-title">Lifecycle Oversight</div>
        <div class="pipe-actor">Secretariat, PI & Committee</div>
        <div class="pipe-details">
          Data Collection monitoring, Annual Continuing Review alerts (60/30 days), Protocol Amendments (AMD-01...), and Final Closeout.
        </div>
        <div class="pipe-badge">Final: <code>Study Archived</code></div>
      </div>
    </div>

    <!-- DECISION OUTCOMES -->
    <div class="decision-section">
      <div class="sec-title">Formal Committee Decision Outcomes & Handling</div>
      <div class="decision-cards">
        <div class="d-card">
          <span class="d-badge green">Approved</span>
          <div class="d-desc">Unconditional ethical clearance. Valid for 12 months. Official certificate issued; data collection begins immediately.</div>
        </div>
        <div class="d-card">
          <span class="d-badge amber">Approved With Conditions</span>
          <div class="d-desc">Ethically sound but requires minor modifications (e.g. translation tweaks, site permission). Tracked until verified.</div>
        </div>
        <div class="d-card">
          <span class="d-badge red">Modifications Required / Deferred</span>
          <div class="d-desc">Substantive flaws or risks. Returned to PI for formal amendment and re-submission, or deferred for external specialist review.</div>
        </div>
      </div>
    </div>

    <!-- LIFECYCLE MANAGEMENT -->
    <div class="lifecycle-row">
      <div class="life-card">
        <h4>Protocol Amendments (AMD-01, AMD-02)</h4>
        <p>Immutable baseline protection: Original approved protocol is never overwritten. Changes are versioned and classified as Minor (Expedited) or Major (Full Board).</p>
      </div>
      <div class="life-card amber">
        <h4>Continuing Review & Expiry Alerts</h4>
        <p>Automated reminders trigger 60 and 30 days prior to the 1-year expiration date. PI submits progress reports to renew clearance.</p>
      </div>
      <div class="life-card green">
        <h4>Study Closeout & Permanent Archive</h4>
        <p>Upon study completion, PI submits final closeout report and data disposition summary. Protocol is formally retired to institutional archives.</p>
      </div>
    </div>

    <div class="infographic-footer">
      <span>Portal: https://aardmc.github.io/AAPHREML-IRERC/</span>
      <span>Addis Ababa City Administration Health Bureau Institutional Research Ethics Review Committee</span>
      <span>Generated for Operational Excellence</span>
    </div>
  </div>
</body>
</html>
`;

// Write the HTML sources
const manualHtmlPath = path.resolve(docsDir, 'AAPHREML_IRERC_Workflow_Manual.html');
const diagramHtmlPath = path.resolve(docsDir, 'AAPHREML_IRERC_Workflow_Diagram.html');

fs.writeFileSync(manualHtmlPath, manualHtml, 'utf8');
fs.writeFileSync(diagramHtmlPath, diagramHtml, 'utf8');
console.log('Written HTML templates successfully.');

// Define Output Targets
const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';

const pdfOutputPathInDocs = path.resolve(docsDir, 'AAPHREML_IRERC_Workflow_Manual.pdf');
const pdfOutputPathInRoot = path.resolve(rootDir, 'AAPHREML_IRERC_Workflow_Manual.pdf');

const pngOutputPathInDocs = path.resolve(docsDir, 'AAPHREML_IRERC_Workflow_Diagram.png');
const pngOutputPathInRoot = path.resolve(rootDir, 'AAPHREML_IRERC_Workflow_Diagram.png');

console.log('Generating PDF via headless Edge...');
execFileSync(edgePath, [
  '--headless=new',
  '--disable-gpu',
  '--no-pdf-header-footer',
  `--user-data-dir=${tempDir}`,
  `--print-to-pdf=${pdfOutputPathInDocs}`,
  `file:///${manualHtmlPath.replace(/\\/g, '/')}`
], { timeout: 30000 });

fs.copyFileSync(pdfOutputPathInDocs, pdfOutputPathInRoot);
console.log('PDF created! Size in bytes:', fs.statSync(pdfOutputPathInDocs).size);

console.log('Generating high-resolution PNG image via headless Edge...');
execFileSync(edgePath, [
  '--headless=new',
  '--disable-gpu',
  '--window-size=1264,1520',
  `--user-data-dir=${tempDir}`,
  `--screenshot=${pngOutputPathInDocs}`,
  `file:///${diagramHtmlPath.replace(/\\/g, '/')}`
], { timeout: 30000 });

fs.copyFileSync(pngOutputPathInDocs, pngOutputPathInRoot);
console.log('PNG created! Size in bytes:', fs.statSync(pngOutputPathInDocs).size);

console.log('Workflow export generation completed successfully!');
